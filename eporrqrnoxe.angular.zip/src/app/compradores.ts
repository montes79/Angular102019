export const Compradores = [
  {
    name: 'Luis Montes',
    phone: 3300006027,
    description: 'Its me'
  },
  {
    name: 'Xavier Lopez',
    phone: 1000001,
    description: 'One eternal!!'
  },
  {
    name: 'Joaquin Guzman',
    phone: 66666600,
    description: 'Tomatoes Sir'
  },
  {
    name: 'El presidente Trom!!',
    phone: 98765432,
    description: 'POTUS'
  }

];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/